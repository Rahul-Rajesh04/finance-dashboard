import { useState, useMemo } from 'react';
import { Transaction } from '../data/mockData';
import { format, isAfter, isBefore, parseISO } from 'date-fns';

export interface TransactionFilters {
  search: string;
  category: string;
  type: 'all' | 'income' | 'expense';
  dateFrom: string;
  dateTo: string;
}

export function useTransactionFilters(transactions: Transaction[]) {
  const [filters, setFilters] = useState<TransactionFilters>({
    search: '',
    category: '',
    type: 'all',
    dateFrom: '',
    dateTo: ''
  });

  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      // Search filter
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        if (!transaction.description.toLowerCase().includes(searchTerm) &&
            !transaction.category.toLowerCase().includes(searchTerm)) {
          return false;
        }
      }

      // Category filter
      if (filters.category && transaction.category !== filters.category) {
        return false;
      }

      // Type filter
      if (filters.type !== 'all' && transaction.type !== filters.type) {
        return false;
      }

      // Date range filter
      if (filters.dateFrom || filters.dateTo) {
        const transactionDate = parseISO(transaction.date);
        
        if (filters.dateFrom) {
          const fromDate = parseISO(filters.dateFrom);
          if (isBefore(transactionDate, fromDate)) {
            return false;
          }
        }
        
        if (filters.dateTo) {
          const toDate = parseISO(filters.dateTo);
          if (isAfter(transactionDate, toDate)) {
            return false;
          }
        }
      }

      return true;
    });
  }, [transactions, filters]);

  const updateFilter = (key: keyof TransactionFilters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      type: 'all',
      dateFrom: '',
      dateTo: ''
    });
  };

  return {
    filters,
    filteredTransactions,
    updateFilter,
    clearFilters
  };
}