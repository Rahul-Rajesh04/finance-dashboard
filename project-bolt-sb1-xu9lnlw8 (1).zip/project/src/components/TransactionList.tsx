import React, { useState } from 'react';
import { format } from 'date-fns';
import { Edit2, Trash2, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Transaction } from '../data/mockData';
import { useFinance } from '../context/FinanceContext';
import { Modal } from './ui/Modal';
import { useToast } from './ui/Toast';

interface TransactionListProps {
  transactions: Transaction[];
  showActions?: boolean;
  limit?: number;
}

export function TransactionList({ transactions, showActions = false, limit }: TransactionListProps) {
  const { deleteTransaction } = useFinance();
  const { showToast } = useToast();
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<Transaction | null>(null);

  const displayTransactions = limit ? transactions.slice(0, limit) : transactions;

  const handleDeleteClick = (transaction: Transaction) => {
    setTransactionToDelete(transaction);
    setDeleteModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (transactionToDelete) {
      deleteTransaction(transactionToDelete.id);
      showToast('Transaction deleted successfully', 'success');
      setDeleteModalOpen(false);
      setTransactionToDelete(null);
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'Food & Dining': 'bg-orange-900/20 text-orange-400 border-orange-800',
      'Transportation': 'bg-blue-900/20 text-blue-400 border-blue-800',
      'Shopping': 'bg-purple-900/20 text-purple-400 border-purple-800',
      'Entertainment': 'bg-pink-900/20 text-pink-400 border-pink-800',
      'Bills & Utilities': 'bg-red-900/20 text-red-400 border-red-800',
      'Healthcare': 'bg-green-900/20 text-green-400 border-green-800',
      'Travel': 'bg-cyan-900/20 text-cyan-400 border-cyan-800',
      'Education': 'bg-indigo-900/20 text-indigo-400 border-indigo-800',
      'Groceries': 'bg-lime-900/20 text-lime-400 border-lime-800',
      'Salary': 'bg-emerald-900/20 text-emerald-400 border-emerald-800',
      'Freelance': 'bg-teal-900/20 text-teal-400 border-teal-800',
      'Investment': 'bg-yellow-900/20 text-yellow-400 border-yellow-800',
      'Gift': 'bg-rose-900/20 text-rose-400 border-rose-800',
      'Other': 'bg-gray-900/20 text-gray-400 border-gray-800'
    };
    return colors[category as keyof typeof colors] || colors.Other;
  };

  if (displayTransactions.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 mx-auto mb-4 bg-gray-800 rounded-full flex items-center justify-center">
          <ArrowUpRight className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-100 mb-2">
          No transactions found
        </h3>
        <p className="text-gray-400">
          {limit ? 'No recent transactions to display.' : 'Try adjusting your filters or add a new transaction.'}
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {displayTransactions.map((transaction) => (
          <div key={transaction.id} className="transaction-card group">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  transaction.type === 'income' 
                    ? 'bg-emerald-900/20 border border-emerald-800' 
                    : 'bg-red-900/20 border border-red-800'
                }`}>
                  {transaction.type === 'income' ? (
                    <ArrowUpRight className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <ArrowDownRight className="w-5 h-5 text-red-400" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-gray-100 truncate">
                      {transaction.description}
                    </h4>
                    <span className={`text-sm font-semibold ${
                      transaction.type === 'income' 
                        ? 'text-emerald-400' 
                        : 'text-red-400'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}
                      ${Math.abs(transaction.amount).toFixed(2)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getCategoryColor(transaction.category)}`}>
                        {transaction.category}
                      </span>
                      <span className="text-xs text-gray-400">
                        {format(new Date(transaction.date), 'MMM d, yyyy')}
                      </span>
                    </div>

                    {showActions && (
                      <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <button
                          className="p-1 text-gray-400 hover:text-indigo-400 transition-colors focus-ring rounded"
                          title="Edit transaction"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteClick(transaction)}
                          className="p-1 text-gray-400 hover:text-red-400 transition-colors focus-ring rounded"
                          title="Delete transaction"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        title="Delete Transaction"
      >
        <div className="space-y-4">
          <p className="text-sm text-gray-300">
            Are you sure you want to delete this transaction? This action cannot be undone.
          </p>
          {transactionToDelete && (
            <div className="p-3 bg-gray-700 rounded-lg border border-gray-600">
              <p className="font-medium text-gray-100">
                {transactionToDelete.description}
              </p>
              <p className="text-sm text-gray-300">
                ${Math.abs(transactionToDelete.amount).toFixed(2)} - {transactionToDelete.category}
              </p>
            </div>
          )}
          <div className="flex space-x-3">
            <button
              onClick={() => setDeleteModalOpen(false)}
              className="flex-1 btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmDelete}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white font-medium py-2.5 px-4 rounded-lg transition-colors duration-200 focus-ring"
            >
              Delete
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}