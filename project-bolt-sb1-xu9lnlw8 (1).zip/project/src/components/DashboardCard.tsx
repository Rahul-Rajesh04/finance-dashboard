import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color: 'indigo' | 'emerald' | 'amber' | 'red';
}

export function DashboardCard({ title, value, icon: Icon, trend, color }: DashboardCardProps) {
  const colorClasses = {
    indigo: 'from-indigo-500 to-indigo-600 text-indigo-400 bg-indigo-900/20',
    emerald: 'from-emerald-500 to-emerald-600 text-emerald-400 bg-emerald-900/20',
    amber: 'from-amber-500 to-amber-600 text-amber-400 bg-amber-900/20',
    red: 'from-red-500 to-red-600 text-red-400 bg-red-900/20'
  };

  return (
    <div className="metric-card group">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-400 mb-1">
            {title}
          </p>
          <p className="text-2xl font-bold text-gray-100">
            {value}
          </p>
          {trend && (
            <div className="flex items-center mt-2">
              <span className={`text-xs font-medium ${
                trend.isPositive ? 'text-emerald-400' : 'text-red-400'
              }`}>
                {trend.isPositive ? '+' : ''}{trend.value}%
              </span>
              <span className="text-xs text-gray-500 ml-1">
                vs last month
              </span>
            </div>
          )}
        </div>
        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${colorClasses[color].split(' ')[0]} ${colorClasses[color].split(' ')[1]} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );
}