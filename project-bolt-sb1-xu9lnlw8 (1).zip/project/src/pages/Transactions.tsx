import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { TransactionList } from '../components/TransactionList';
import { TransactionFiltersComponent } from '../components/TransactionFilters';
import { useTransactionFilters } from '../hooks/useTransactionFilters';
import { CreditCard } from 'lucide-react';

export function Transactions() {
  const { transactions } = useFinance();
  const { filters, filteredTransactions, updateFilter, clearFilters } = useTransactionFilters(transactions);

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        <div className="page-header">
          <div className="flex items-center space-x-3 mb-2">
            <CreditCard className="w-8 h-8 text-indigo-400" />
            <h1 className="page-title">
              Transactions
            </h1>
          </div>
          <p className="page-subtitle">
            Manage and view all your financial transactions.
          </p>
        </div>

        <div className="space-y-6">
          {/* Filters */}
          <TransactionFiltersComponent
            filters={filters}
            onFilterChange={updateFilter}
            onClearFilters={clearFilters}
            resultsCount={filteredTransactions.length}
          />

          {/* Transactions List */}
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="section-title">
                All Transactions
              </h2>
              <div className="text-sm text-gray-400">
                {filteredTransactions.length} of {transactions.length} transactions
              </div>
            </div>
            
            <TransactionList 
              transactions={filteredTransactions} 
              showActions={true}
            />
          </div>
        </div>
      </div>
    </div>
  );
}