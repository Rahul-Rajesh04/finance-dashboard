import React from 'react';
import { Link } from 'react-router-dom';
import { Wallet, TrendingUp, TrendingDown, Plus, BarChart3, PieChart } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { DashboardCard } from '../components/DashboardCard';
import { TransactionList } from '../components/TransactionList';
import { IncomeExpenseChart } from '../components/IncomeExpenseChart';

export function Dashboard() {
  const { getTotalIncome, getTotalExpenses, getBalance, getRecentTransactions } = useFinance();

  const totalIncome = getTotalIncome();
  const totalExpenses = getTotalExpenses();
  const balance = getBalance();
  const recentTransactions = getRecentTransactions(5);

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        <div className="page-header">
          <h1 className="page-title">
            Dashboard
          </h1>
          <p className="page-subtitle">
            Welcome back! Here's an overview of your finances.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <DashboardCard
            title="Total Balance"
            value={`$${balance.toFixed(2)}`}
            icon={Wallet}
            color={balance >= 0 ? 'emerald' : 'red'}
            trend={{ value: 12.5, isPositive: balance >= 0 }}
          />
          <DashboardCard
            title="Total Income"
            value={`$${totalIncome.toFixed(2)}`}
            icon={TrendingUp}
            color="emerald"
            trend={{ value: 8.2, isPositive: true }}
          />
          <DashboardCard
            title="Total Expenses"
            value={`$${totalExpenses.toFixed(2)}`}
            icon={TrendingDown}
            color="red"
            trend={{ value: -3.1, isPositive: false }}
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-gray-400" />
                <h2 className="section-title">
                  Income vs Expenses
                </h2>
              </div>
            </div>
            <IncomeExpenseChart type="bar" />
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <PieChart className="w-5 h-5 text-gray-400" />
                <h2 className="section-title">
                  Spending by Category
                </h2>
              </div>
            </div>
            <IncomeExpenseChart type="doughnut" />
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h2 className="section-title">
                  Recent Transactions
                </h2>
                <Link
                  to="/transactions"
                  className="text-sm text-indigo-400 hover:text-indigo-300 font-medium transition-colors focus-ring rounded px-2 py-1"
                >
                  View all
                </Link>
              </div>
              <TransactionList transactions={recentTransactions} limit={5} />
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <div className="card">
              <h3 className="section-title mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                <Link
                  to="/add-transaction"
                  className="flex items-center space-x-3 p-3 rounded-lg bg-indigo-900/20 text-indigo-300 hover:bg-indigo-900/30 transition-colors group focus-ring"
                >
                  <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Plus className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-medium">Add Transaction</span>
                </Link>
                
                <Link
                  to="/transactions"
                  className="flex items-center space-x-3 p-3 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600 transition-colors group focus-ring"
                >
                  <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <BarChart3 className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-medium">View All Transactions</span>
                </Link>
              </div>
            </div>

            {/* Financial Summary */}
            <div className="card">
              <h3 className="section-title mb-4">
                This Month
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">Income</span>
                  <span className="text-sm font-semibold text-emerald-400">
                    +${(totalIncome * 0.3).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">Expenses</span>
                  <span className="text-sm font-semibold text-red-400">
                    -${(totalExpenses * 0.4).toFixed(2)}
                  </span>
                </div>
                <div className="pt-2 border-t border-gray-700">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-100">Net</span>
                    <span className={`text-sm font-bold ${
                      balance >= 0 
                        ? 'text-emerald-400' 
                        : 'text-red-400'
                    }`}>
                      {balance >= 0 ? '+' : '-'}${Math.abs(balance * 0.2).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}