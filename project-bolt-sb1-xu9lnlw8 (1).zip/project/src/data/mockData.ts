export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  category: string;
  type: 'income' | 'expense';
}

export const categories = [
  'Food & Dining',
  'Transportation',
  'Shopping',
  'Entertainment',
  'Bills & Utilities',
  'Healthcare',
  'Travel',
  'Education',
  'Groceries',
  'Salary',
  'Freelance',
  'Investment',
  'Gift',
  'Other'
];

export const mockTransactions: Transaction[] = [
  {
    id: '1',
    date: '2024-01-15',
    description: 'Monthly Salary',
    amount: 5000,
    category: 'Salary',
    type: 'income'
  },
  {
    id: '2',
    date: '2024-01-14',
    description: 'Grocery Shopping at Whole Foods',
    amount: -89.50,
    category: 'Groceries',
    type: 'expense'
  },
  {
    id: '3',
    date: '2024-01-13',
    description: 'Uber Ride to Downtown',
    amount: -25.30,
    category: 'Transportation',
    type: 'expense'
  },
  {
    id: '4',
    date: '2024-01-12',
    description: 'Freelance Web Development',
    amount: 800,
    category: 'Freelance',
    type: 'income'
  },
  {
    id: '5',
    date: '2024-01-11',
    description: 'Dinner at Italian Restaurant',
    amount: -65.80,
    category: 'Food & Dining',
    type: 'expense'
  },
  {
    id: '6',
    date: '2024-01-10',
    description: 'Netflix Subscription',
    amount: -15.99,
    category: 'Entertainment',
    type: 'expense'
  },
  {
    id: '7',
    date: '2024-01-09',
    description: 'Electric Bill',
    amount: -120.45,
    category: 'Bills & Utilities',
    type: 'expense'
  },
  {
    id: '8',
    date: '2024-01-08',
    description: 'Online Course Purchase',
    amount: -199.99,
    category: 'Education',
    type: 'expense'
  },
  {
    id: '9',
    date: '2024-01-07',
    description: 'Clothing Store Purchase',
    amount: -145.20,
    category: 'Shopping',
    type: 'expense'
  },
  {
    id: '10',
    date: '2024-01-06',
    description: 'Coffee Shop',
    amount: -12.75,
    category: 'Food & Dining',
    type: 'expense'
  },
  {
    id: '11',
    date: '2024-01-05',
    description: 'Investment Dividend',
    amount: 150,
    category: 'Investment',
    type: 'income'
  },
  {
    id: '12',
    date: '2024-01-04',
    description: 'Gas Station Fill-up',
    amount: -48.90,
    category: 'Transportation',
    type: 'expense'
  },
  {
    id: '13',
    date: '2024-01-03',
    description: 'Doctor Visit Copay',
    amount: -35.00,
    category: 'Healthcare',
    type: 'expense'
  },
  {
    id: '14',
    date: '2024-01-02',
    description: 'Birthday Gift from Parents',
    amount: 200,
    category: 'Gift',
    type: 'income'
  },
  {
    id: '15',
    date: '2024-01-01',
    description: 'New Year Celebration',
    amount: -85.60,
    category: 'Entertainment',
    type: 'expense'
  }
];